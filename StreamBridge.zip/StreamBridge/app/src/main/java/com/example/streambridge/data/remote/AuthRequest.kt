package com.example.streambridge.data.remote



data class AuthRequest(
    val email: String,
    val password: String
)